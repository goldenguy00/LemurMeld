# 1.0.4

fixed lemur inventory not updating on summon

# 1.0.3

supports modded elites
lemurians will drop 1 scrap for each unique item that they had on death.
lemurians will now switch between the various high tier elite types once they are fully evolved

# 1.0.2

fixed it changing the first guy spawned

# 1.0.0

Release lemur meld