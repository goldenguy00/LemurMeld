# Dronemeld Devotion Fix

makes your lemurians fuse together like dragonball

![dbz](https://static1.srcdn.com/wordpress/wp-content/uploads/2017/10/DBZ-Fusion-Goku-and-Piccolo-Featured.jpg?q=50&fit=contain&w=1140&h=&dpr=1.5)

supports modded elites
lemurians will drop 1 scrap for each unique item that they had on death.
lemurians will now switch between the various high tier elite types once they are fully evolved

config and more changes coming soon...