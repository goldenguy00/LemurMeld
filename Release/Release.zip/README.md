# Dronemeld Devotion Fix

makes your lemurians fuse together like dragonball

![dbz](https://static1.srcdn.com/wordpress/wp-content/uploads/2017/10/DBZ-Fusion-Goku-and-Piccolo-Featured.jpg?q=50&fit=contain&w=1140&h=&dpr=1.5)

modded elite support will be added soon (probably)